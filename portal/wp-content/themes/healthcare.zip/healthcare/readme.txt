Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/healthcare/
Buy theme: http://smthemes.com/buy/healthcare/
Support Forums: http://smthemes.com/support/forum/healthcare-free-wordpress-theme/